package application.model;

public class ClassesPointDTO {
    private String FAU;
    private String FCO;
    private String FCS;
    private String FDP;
    private String FIA;
    private String FMT;
    private String FPR;
    private String FPT;
    private String FRU;
    private String FTA;
    private String FTP;

    public String getFAU() {
        return FAU;
    }

    public void setFAU(String FAU) {
        this.FAU = FAU;
    }

    public String getFCO() {
        return FCO;
    }

    public void setFCO(String FCO) {
        this.FCO = FCO;
    }

    public String getFCS() {
        return FCS;
    }

    public void setFCS(String FCS) {
        this.FCS = FCS;
    }

    public String getFDP() {
        return FDP;
    }

    public void setFDP(String FDP) {
        this.FDP = FDP;
    }

    public String getFIA() {
        return FIA;
    }

    public void setFIA(String FIA) {
        this.FIA = FIA;
    }

    public String getFMT() {
        return FMT;
    }

    public void setFMT(String FMT) {
        this.FMT = FMT;
    }

    public String getFPR() {
        return FPR;
    }

    public void setFPR(String FPR) {
        this.FPR = FPR;
    }

    public String getFPT() {
        return FPT;
    }

    public void setFPT(String FPT) {
        this.FPT = FPT;
    }

    public String getFRU() {
        return FRU;
    }

    public void setFRU(String FRU) {
        this.FRU = FRU;
    }

    public String getFTA() {
        return FTA;
    }

    public void setFTA(String FTA) {
        this.FTA = FTA;
    }

    public String getFTP() {
        return FTP;
    }

    public void setFTP(String FTP) {
        this.FTP = FTP;
    }
}
