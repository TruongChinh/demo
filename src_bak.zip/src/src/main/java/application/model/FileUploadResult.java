package application.model;


public class FileUploadResult extends BaseApiResult {
    private String link;

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
