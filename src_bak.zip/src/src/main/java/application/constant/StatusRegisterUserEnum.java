package application.constant;

public enum StatusRegisterUserEnum {
    Existed_Username,
    Error_OnSystem,
    Success
}
