package application.common;

import application.model.DataApiResult;
import org.springframework.http.HttpStatus;

public class Common {
    public static DataApiResult setResult(DataApiResult rs, int http, String mess, Object data){
        rs.setData(data);
        rs.setMessage(mess);
        rs.setHttp(http);
        return rs;
    }

    public static DataApiResult setResult(DataApiResult rs, int http, Object data){
        if(http == HttpStatus.OK.value()){
            setResult(rs, http, "success", data);
        }else if(http == HttpStatus.INTERNAL_SERVER_ERROR.value()){
            setResult(rs, http, "failed", null);
        }else if(http == HttpStatus.NO_CONTENT.value()){
            setResult(rs, http, "success", null);
        }
        return rs;
    }

}
